document.querySelectorAll('.gallery').forEach((gallery, index) => {
    const galleryContainer = gallery.querySelector('.gallery-container');
    const prevBtn = gallery.querySelector('.prev-btn');
    const nextBtn = gallery.querySelector('.next-btn');

    let currentIndex = 0;
    const totalImages = galleryContainer.querySelectorAll('.gallery-image').length;

    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateGallery();
        }
    });

    nextBtn.addEventListener('click', () => {
        if (currentIndex < totalImages - 4) {
            currentIndex++;
            updateGallery();
        }
    });

    function updateGallery() {
        const offset = -currentIndex * 260; // 250px (ширина фото) + 10px (отступ)
        galleryContainer.style.transform = `translateX(${offset}px)`;
    }
});

let sliderPosition = 0;

function shiftSlider(shiftPercentage) {
    sliderPosition += shiftPercentage;
    // Prevent slider from going too far
    sliderPosition = Math.max(sliderPosition, -100 * (slider.children.length - 1));
    sliderPosition = Math.min(sliderPosition, 0);
    slider.style.transform = `translateX(${sliderPosition}%)`;
}

window.onscroll = function() {
  toggleScrollToTopButton();
};

function toggleScrollToTopButton() {
  var button = document.querySelector('.scroll-to-top');
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      button.style.display = 'flex';
  } else {
      button.style.display = 'none';
  }
}

function scrollToTop() {
    document.body.scrollTop = 0; // Для Safari
    document.documentElement.scrollTop = 0; // Для Chrome, Firefox, IE и Opera
  }